export inputPath="$1"
osascript <<SCRIPT
set inputPath to quoted form of (system attribute "inputPath")
tell application "iTerm"
tell current window
create tab with default profile
activate
tell the current tab
activate current session
launch session "Default Session"
tell the last session
write text "cd " & inputPath & ";clear;"
end tell
end tell

end tell
end tell
SCRIPT
