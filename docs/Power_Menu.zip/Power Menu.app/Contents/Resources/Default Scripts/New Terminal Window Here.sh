open -a Terminal "$1"
