export inputPath="$1"
osascript <<SCRIPT
set inputPath to quoted form of (system attribute "inputPath")
tell application "Terminal"
  if (exists window 1) and not busy of window 1 then
    do script "emacs " & inputPath in window 1
  else
    do script "emacs " & inputPath
  end if

  activate
end tell
SCRIPT
