defaults write com.apple.finder AppleShowAllFiles -bool FALSE
killall Finder
