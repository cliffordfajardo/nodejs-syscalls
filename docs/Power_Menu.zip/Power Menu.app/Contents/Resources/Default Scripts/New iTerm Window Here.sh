export inputPath="$1"
osascript <<SCRIPT
set inputPath to quoted form of (system attribute "inputPath")
tell application "iTerm"
  create window with default profile
  activate
  tell the current window
    activate current session
    tell current session
      write text "cd " & inputPath & "; clear"
    end tell
  end tell
end tell
SCRIPT
