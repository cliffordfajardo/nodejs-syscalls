export inputPath="$1"
osascript <<SCRIPT
set inputPath to quoted form of (system attribute "inputPath")
tell application "Terminal"
  if not (exists window 1) then reopen
	activate
	delay 0.5
	tell application "System Events" to keystroke "t" using {command down}
	do script "cd " & inputPath in window 1
end tell
SCRIPT
